23BIS70049
23BIS-1(B)

Learning outcomes
Learnt State Management in ReactJS

Learnt about state and it's types

Learn about Local & Global State

Learnt about components and props

Learnt about problems without State Management

Learnt about ContextAPI & Redux and there difference and implementation