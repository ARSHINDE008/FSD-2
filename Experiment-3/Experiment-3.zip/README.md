23BIS70049
23BIS-1(B)

Learning Outcomes

After completing this experiment, I learned to:

Create and run a React application using Vite and manage it using npm.

Understand the project structure and organize components effectively.

Design a modern card-based UI with interactive Button and TextField components.

Implement client-side routing using BrowserRouter, Routes, and Route.

Navigate between pages smoothly using Link without reloading the browser.
