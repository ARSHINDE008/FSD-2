23BIS70049
23BIS-1(B)

LEARNING OUTCOMES-

Learned to create and manage forms in ReactJS using Material UI components.

Implemented built-in and custom validations for form inputs.

Understood form state handling using the useState hook.

Learned to handle form submission and error display in frontend applications.