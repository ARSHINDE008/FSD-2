23BIS70049 - 23bis-1(B)

# Learning outcomes
- Learnt about Lazy Loading in ReactJS
- Learnt about  React.lazy()
- Learnt about implementation of Lazy Loading

